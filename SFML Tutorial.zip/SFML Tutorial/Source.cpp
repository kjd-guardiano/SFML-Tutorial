// SFML Testing Ground!

#include "SFML/Graphics.hpp"
#include "stdlib.h"
#include "time.h"
#include "iostream"

/* DEV NOTES:
*   General game loop is as follows:
*   while(game_running){
*       ProcessEventsAndInput();
*       if(!game_paused){
*          UpdateWorld();
*       }
*       DrawWorld();
*   }
*/

//Variable Declaration Start
sf::RenderWindow mainWindow(sf::VideoMode(1440, 900), "The Game", sf::Style::Titlebar | sf::Style::Close);
bool focus;
bool paused;
bool aCorrect;
bool sCorrect;
bool dCorrect;
bool fCorrect;
/*NOTE: 
* this is the formula for creating a square in the top-left.
* in order to make more, you need to make *more* shapes, then
* create interactions for each of them. the four bools above
* are for mapping to keybinds to circumvent the need for 
* real-time mouse tracking.
*/
sf::Vertex test_square[] =
{
    sf::Vertex(sf::Vector2f(0,   0), sf::Color::Red, sf::Vector2f(0,  0)),
    sf::Vertex(sf::Vector2f(0, 100), sf::Color::Red, sf::Vector2f(0, 10)),
    sf::Vertex(sf::Vector2f(100, 100), sf::Color::Red, sf::Vector2f(10, 10)),
    sf::Vertex(sf::Vector2f(100,   0), sf::Color::Red, sf::Vector2f(10,  0))
};
//Variable Declaration End

//Function Prototype Start
void windowSetup();
void testDraw();
void wipeScreen();
//Function Prototype End

int main()
{
    windowSetup();
    paused = false;

    while (mainWindow.isOpen()) {
        //checks if window is currently in user focus ("tabbed in")
        focus = mainWindow.hasFocus();
        //for detecting events
        sf::Event event;

        //event detection loop
        while (mainWindow.pollEvent(event)) {
            switch (event.type) {
                //close window
                case sf::Event::Closed:
                    mainWindow.close();
                    break;
                //window out of focus
                case sf::Event::LostFocus:
                    paused = true;
                    std::cout << "PAUSED" << std::endl; //outputs to CONSOLE, not SFML window
                    break;
                //window back in focus
                case sf::Event::GainedFocus:
                    paused = false;
                    std::cout << "UNPAUSED" << std::endl; //outputs to CONSOLE, not SFML window
                    break;
                //mouse over buttons?
                //manual pause
                case sf::Event::KeyPressed:
                    if (sf::Keyboard::isKeyPressed(sf::Keyboard::P) && !paused) {
                        paused = true;
                        wipeScreen();
                    }
                    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::P) && paused) {
                        paused = false;
                    }
                default:
                    wipeScreen();
                    break;
            }
            //outside of switch statement
            if (!paused) {
                testDraw();
            }
            mainWindow.display();
        }
        //outside of while loop

    }
}

void windowSetup() {
    bool focus = mainWindow.hasFocus();
    mainWindow.setVerticalSyncEnabled(true);
    mainWindow.setFramerateLimit(60);
    mainWindow.clear();
    std::cout << "The window has been modified!" << std::endl;
}

void wipeScreen() {
    mainWindow.clear();
}

void testDraw() {
    mainWindow.clear();
    mainWindow.draw(test_square, 4, sf::Quads);
}